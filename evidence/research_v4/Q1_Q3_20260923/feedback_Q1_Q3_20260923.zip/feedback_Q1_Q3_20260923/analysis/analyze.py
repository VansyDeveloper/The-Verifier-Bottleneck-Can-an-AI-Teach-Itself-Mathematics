#!/usr/bin/env python3
"""CPU-only replay of the two Q1/Q3 exports. Never loads model weights.

Usage: python analyze.py [--archives REPO_ROOT] [--out OUTPUT_DIRECTORY]
Requires numpy, scipy, torch and matplotlib already used by the archived project.
Original primary comparisons are delegated to the exact archived v4 analyzer.
"""

import argparse
from collections import Counter, defaultdict
import csv
from functools import lru_cache
import hashlib
import itertools
import json
import os
from pathlib import Path, PurePosixPath
import sys
import tempfile
from zipfile import ZipFile

import numpy as np

ARCHIVES = {
    'Q1': ('send_to_artem_exp_v4_Q1_q06_a3_20260922_183740_777821.zip',
           'fa8b5f7d295bd5d496a6bd8628bcc1653a73de3fc302e1a3cc9c15104f49a59d'),
    'Q3': ('send_to_artem_exp_v4_Q3_q06_a3_20260922_200730_425509.zip',
           'c04eacbbd070d5f0362bd022b911b7fa05dbfe301f915cba4905a43d2d060ed2'),
}
COMMIT = 'c37cfe083787f21af9a9aab0ef1d02c63cf603d3'
CODE_HASH = 'fbbde31e0adc4bbd50d4c8567c14578e387a13bdcac1955041c80dbed94e4763'


def read(path):
    return json.loads(Path(path).read_text())


def lines(path):
    with Path(path).open() as stream:
        for line in stream:
            if line.strip():
                yield json.loads(line)


def save(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n')


def sha(path):
    with Path(path).open('rb') as stream:
        h = hashlib.sha256()
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def table(path, rows):
    keys = list(dict.fromkeys(k for row in rows for k in row))
    with Path(path).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def unpack(source, expected, destination):
    assert sha(source) == expected, source
    with ZipFile(source) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)), 'Duplicate archive entries'
        for name in names:
            path = PurePosixPath(name)
            assert not path.is_absolute() and '..' not in path.parts, name
        manifest = json.loads(archive.read('EXPORT_MANIFEST.json'))
        assert manifest['status'] == 'complete' and manifest['source_code_hash'] == CODE_HASH
        assert set(names) == {r['path'] for r in manifest['files']} | {'EXPORT_MANIFEST.json'}
        for row in manifest['files']:
            content = archive.read(row['path'])
            assert len(content) == row['bytes'] and hashlib.sha256(content).hexdigest() == row['sha256'], row['path']
        archive.extractall(destination)
    return {'archive': source.name, 'sha256': expected, 'verified_files': len(manifest['files']),
            'source_code_hash': manifest['source_code_hash'], 'includes_weights': manifest['includes_weights']}


def paired_bootstrap(by_family):
    """Equal-family mean; values are already paired and averaged across seeds."""
    rng = np.random.default_rng(20260922)
    draws = []
    for family in sorted(by_family):
        values = np.asarray(by_family[family], dtype=float)
        assert len(values) and np.isfinite(values).all()
        draws.append(values[rng.integers(len(values), size=(2000, len(values)))].mean(1))
    return {'estimate': float(np.mean([np.mean(v) for v in by_family.values()])),
            'ci95': np.quantile(np.mean(draws, axis=0), [.025, .975]).tolist(),
            'units': {f: len(v) for f, v in by_family.items()}}


def extra_contrast(units, queue, weights):
    """Exploratory linear contrasts, including the actual 2x2 interaction."""
    arms = {}
    for arm in weights:
        runs = [v for (q, a, seed), v in units.items() if (q, a) == (queue, arm)]
        assert runs and all(set(v) == set(runs[0]) for v in runs)
        arms[arm] = {k: float(np.mean([v[k] for v in runs])) for k in runs[0]}
    keys = set(next(iter(arms.values())))
    assert all(set(v) == keys for v in arms.values()), 'Unpaired observations'
    deltas = {k: sum(weights[a] * arms[a][k] for a in arms) for k in keys}
    results = {}
    for metric in sorted({k[0] for k in keys}):
        grouped = {f: [v for (m, family, unit), v in sorted(deltas.items()) if m == metric and family == f]
                   for f in ('B', 'D')}
        if not all(grouped.values()):
            continue
        result = paired_bootstrap(grouped)
        result['families'] = {f: paired_bootstrap({f: v}) for f, v in grouped.items()}
        results[metric] = result
    return {'weights': weights, 'endpoints': results,
            'scope': 'Exploratory; 2000 paired panel/START-cluster bootstrap draws; seeds averaged first; equal B/D; conditional on observed checkpoints and mask.'}


def self_check():
    assert paired_bootstrap({'B': [1, 1], 'D': [-1, -1]})['ci95'] == [0., 0.]
    # Seed replication must not multiply the number of experimental units.
    fixture = {('Q', a, s): {('m', f, 'one'): v for f in ('B', 'D')}
               for a, v in [('c', 2), ('t', 5)] for s in range(3)}
    r = extra_contrast(fixture, 'Q', {'t': 1, 'c': -1})['endpoints']['m']
    assert r['estimate'] == 3 and r['units'] == {'B': 1, 'D': 1}
    q = np.ones(125) / 125
    assert np.isclose(-np.sum(q * np.log(q)), np.log(125))
    assert np.isclose(-np.expm1(32 * np.log1p(-q[0])), 1 - (124 / 125) ** 32)


def analyze(work, out):
    sys.path.insert(0, str(work / 'Q1/code'))
    import torch
    import iclr.common as common
    import composition_core as core
    from iclr.research_analysis import compare
    from iclr.research_data import check_panels
    from iclr.research_objectives import entropy_report
    from iclr.upgrade_data import affine_maps
    torch.set_num_threads(1)
    assert common.code_hash() == CODE_HASH
    metrics, atomic, diagnostics, curves, panel_table = [], [], [], [], []
    units, support, training, verification, examples = {}, {}, {}, {}, {}
    topology_cache, labels = {}, {}

    @lru_cache(maxsize=None)
    def program_data(depth):
        programs = list(core.enumerate_programs(depth))
        return programs, {p: i for i, p in enumerate(programs)}

    for queue, mask in [('Q1', 'original'), ('Q3', 'mask1')]:
        root = work / queue / 'results'
        status = read(root / 'status.json')
        assert all(r['status'] == 'done' for r in status['jobs'].values())
        assert sha(root / 'queue.json') == status['queue_sha256']
        for dataset in (root / 'data').iterdir():
            if dataset.is_dir():
                common.verify_data(dataset)
        dataset = root / 'data' / mask
        manifest = read(dataset / 'manifest.json')
        support[queue] = {'mask': mask, 'constraints': manifest['constraints'], 'splits': {}}
        data_rows = {}
        for path in sorted(dataset.glob('*.jsonl')):
            rows = list(lines(path))
            if path.stem == 'train_crossed' or path.stem.startswith(('dev_', 'dev4_')):
                support[queue]['splits'][path.stem] = {
                    'tasks': len(rows), 'panels': len({r['panel_id'] for r in rows if r.get('panel_id')}),
                    'unique_witnesses': len({tuple(r['witness']) for r in rows}),
                    'correct_counts': dict(Counter(r['correct_count'] for r in rows)),
                    'fields': dict(Counter(r['p'] for r in rows))}
            if path.stem.startswith(('dev_', 'dev4_')) and path.stem != 'dev_atomic':
                for row in rows:
                    assert row['task_id'] not in data_rows
                    data_rows[row['task_id']] = row
        motifs = set(map(tuple, manifest['constraints']['heldout_motifs']))
        held = np.array([bool(set(zip(p, p[1:])) & motifs) for p in program_data(3)[0]])
        support[queue]['heldout_candidates_depth3'] = int(held.sum())
        for path in sorted((root / 'evaluations').iterdir()):
            print('Replay', queue, path.name, flush=True)
            receipt = common.verify_receipt(path)
            binding = read(path / 'binding.json')
            cfg = binding['config']
            assert binding == receipt['binding']
            assert binding['code_hash'] == CODE_HASH and binding['plan_hash'] == sha(work / queue / 'code/plans/research_v4.json')
            assert binding['data_hash'] == sha(dataset / 'manifest.json')
            assert cfg['phase'] == 'dev' and cfg['dtype'] == 'bfloat16'
            assert read(path / 'environment.json')['git_commit'] == COMMIT
            meta = {'queue': queue, 'mask': mask, 'arm': cfg['arm'], 'seed': cfg['seed']}
            observed = defaultdict(list)
            compact = defaultdict(list)
            diag, per_curve, row_panels = defaultdict(list), defaultdict(list), []
            mode = defaultdict(Counter)
            max_score_error, max_entropy_error = 0., 0.
            all_rows = list(lines(path / 'rankings.jsonl'))
            prefixes = list(lines(path / 'prefixes.jsonl'))
            assert len(all_rows) == len(data_rows) == len(prefixes)
            assert {r['task_id'] for r in all_rows} == set(data_rows)
            for row, prefix in zip(all_rows, prefixes):
                assert prefix['task_id'] == row['task_id']
                assert all(row[k] == v for k, v in data_rows[row['task_id']].items())
                programs, indices = program_data(row['depth'])
                label_key = queue, row['task_id']
                if label_key not in labels:
                    ps, matrices, offsets = affine_maps(row['p'], row['degree'], row['depth'])
                    answers = (matrices @ np.asarray(row['start']) + offsets) % row['p']
                    solutions = [p for p, ok in zip(ps, (answers == row['target']).all(1)) if ok]
                    assert sorted(solutions) == sorted(map(tuple, row['correct_programs']))
                    assert row['correct_count'] == len(solutions)
                    labels[label_key] = np.array([p in solutions for p in programs])
                correct = labels[label_key]
                topology = tuple(tuple(v['prefix']) for v in prefix['prefixes'])
                if topology not in topology_cache:
                    pos = {v: i for i, v in enumerate(topology)}
                    topology_cache[topology] = (np.array([[pos[p[:i]] for i in range(len(p))] for p in programs]),
                                               np.array([[core.OPS.index(op) for op in p] for p in programs]))
                loc, actions = topology_cache[topology]
                full = torch.tensor([v['full_action_logprobs'] for v in prefix['prefixes']], dtype=torch.float32)
                for policy, scores in [('full', full), ('local', full.log_softmax(-1))]:
                    recovered = scores[loc, actions].numpy().sum(1)
                    error = float(np.max(np.abs(recovered - row[policy])))
                    max_score_error = max(max_score_error, error)
                    assert error < 2e-5, (path, row['task_id'], policy, error)
                    computed = entropy_report(row[policy], correct, programs, row['p'], row['degree'])
                    for actual, expected in zip(computed, row['entropy'][policy]):
                        for key in expected:
                            error = abs(actual[key] - expected[key])
                            max_entropy_error = max(max_entropy_error, error)
                            assert error < 1e-10, (row['task_id'], key)
                kind = row.get('panel_kind', 'four_target' if row.get('panel_id') else 'ordinary')
                for policy, reports in row['entropy'].items():
                    for report in reports:
                        observed[row['family'], row['depth'], kind, policy, report['temperature']].append(report)
                if row.get('panel_id'):
                    row_panels.append(row)
                    continue
                if row['depth'] != 3:
                    continue
                report = next(v for v in row['entropy']['local'] if v['temperature'] == 1)
                p = np.exp(np.array(row['local']) - max(row['local'])); p /= p.sum()
                values = dict(report)
                values.update(sample_success32=float(-np.expm1(32 * np.log1p(-report['correct_mass']))),
                              heldout_mass=float(p[held].sum()))
                if row['family'] in ('B', 'D'):
                    assert correct.sum() == 1 and not (correct & ~held).any()
                    restricted = sorted(np.flatnonzero(held), key=lambda i: (-row['local'][i], programs[i]))
                    rank = next(i + 1 for i, index in enumerate(restricted) if correct[index])
                    values.update(restricted_hit1=float(rank <= 1), restricted_hit8=float(rank <= 8),
                                  restricted_rank=rank, conditional_correct_mass=float(p[correct].sum() / p[held].sum()))
                values.pop('temperature')
                diag[row['family']].append(values)
                unit = json.dumps([row['p'], row['start']])
                for name, value in values.items():
                    compact[name, row['family'], unit].append(float(value))
                ranks = np.arange(1, 126) >= report['first_correct_rank']
                per_curve[row['family']].append(ranks.astype(float))
                best = sorted(range(len(programs)), key=lambda i: (-row['local'][i], programs[i]))[0]
                mode[row['family']][' '.join(programs[best])] += 1
            saved_summary = read(path / 'summary.json')
            assert saved_summary['binding'] == binding and len(observed) == len(saved_summary['metrics'])
            for item in saved_summary['metrics']:
                selected = observed[item['family'], item['depth'], item['kind'], item['policy'], item['temperature']]
                assert len(selected) == item['n']
                for key in selected[0]:
                    assert np.isclose(np.mean([r[key] for r in selected]), item[key], rtol=0, atol=1e-12)
                metrics.append({**meta, **item})
            saved_panels = read(path / 'panel_metrics.json')
            assert saved_panels['binding'] == binding
            keyed = {(r['panel_id'], r['policy']): r for r in saved_panels['panels']}
            for panel in check_panels(row_panels):
                crossed = panel[0].get('panel_kind') == 'crossed'
                choices = [panel[0]['program_A'], panel[0]['program_B']] if crossed else [r['witness'] for r in panel]
                inds = [program_data(panel[0]['depth'])[1][tuple(p)] for p in choices]
                for policy in ('local', 'full'):
                    matrix = np.array([[r[policy][i] for i in inds] for r in panel])
                    saved = keyed[panel[0]['panel_id'], policy]
                    if crossed:
                        margin = (matrix[:, 0] - matrix[:, 1]) * np.array([1, -1, -1, 1])
                        credit = (margin > 1e-8) + .5 * (abs(margin) <= 1e-8)
                        calculated = dict(interaction=float(margin.sum()), cell_accuracy=float(credit.mean()),
                                          joint_accuracy=float(credit.prod()), all_cells_strict=bool((margin > 1e-8).all()))
                    else:
                        cycles = np.array([matrix[i, i] + matrix[j, j] - matrix[i, j] - matrix[j, i]
                                           for i, j in itertools.combinations(range(4), 2)])
                        assignments = np.array([sum(matrix[i, j] for i, j in enumerate(order))
                                                for order in itertools.permutations(range(4))])
                        best = assignments.max()
                        calculated = dict(pair_accuracy=float(((cycles > 1e-8) + .5 * (abs(cycles) <= 1e-8)).mean()),
                                          mean_cycle=float(cycles.mean()), assignment_accuracy=float(
                                              1 / sum(abs(assignments - best) <= 1e-8) if abs(assignments[0] - best) <= 1e-8 else 0))
                    for key, value in calculated.items():
                        assert np.isclose(value, saved[key], rtol=0, atol=1e-12)
                    panel_table.append({**meta, **{k: saved[k] for k in ('panel_id', 'family', 'depth', 'p', 'policy', 'kind')}, **calculated})
                    if policy == 'local':
                        for key, value in calculated.items():
                            compact['panel_' + key, saved['family'], saved['panel_id']].append(float(value))
                        if crossed and saved['family'] in ('B', 'D'):
                            for r in panel:
                                m = next(v for v in r['entropy']['local'] if v['temperature'] == 1)
                                compact['crossed_full_hit1', saved['family'], saved['panel_id']].append(float(m['hit1']))
            for family, values in diag.items():
                diagnostics.append({**meta, 'family': family, 'n': len(values),
                                    **{k: float(np.mean([v[k] for v in values])) for k in values[0]}})
                for k, value in enumerate(np.mean(per_curve[family], axis=0), 1):
                    curves.append({**meta, 'family': family, 'k': k, 'hit': float(value)})
            examples[queue + '/' + path.name] = {f: counts.most_common(5) for f, counts in mode.items()}
            ret = read(path / 'atomic_retention.json')
            for op in ('ALL', *core.OPS):
                planned = [r for r in ret['plan'] if op == 'ALL' or r['operation'] == op]
                applied = [r for r in ret['apply'] if op == 'ALL' or r['witness'][0] == op]
                assert {r['task_id'] for r in planned} == {r['task_id'] for r in applied}
                atomic.append({**meta, 'operation': op, 'n': len(planned),
                               'plan': float(np.mean([r['correct'] for r in planned])),
                               'apply': float(np.mean([r['semantic_correct'] for r in applied])),
                               'plan_parse': float(np.mean([r['parse_ok'] for r in planned])),
                               'apply_parse': float(np.mean([r['parse_ok'] for r in applied]))})
            units[queue, cfg['arm'], cfg['seed']] = {k: float(np.mean(v)) for k, v in compact.items()}
            verification[queue + '/' + path.name] = {'receipt': sha(path / 'DONE'), 'scored_tasks': len(all_rows),
                'panels': len(saved_panels['panels']) // 2, 'max_prefix_score_error': max_score_error,
                'max_entropy_metric_error': max_entropy_error, 'binding': binding, 'environment': read(path / 'environment.json')}
        if (root / 'training').exists():
            streams = set()
            for path in sorted((root / 'training').iterdir()):
                receipt = common.verify_receipt(path)
                stream = list(lines(path / 'training_stream.jsonl'))
                log = list(lines(path / 'training_metrics.jsonl'))
                budget, reload = read(path / 'budget.json'), read(path / 'reload_check.json')
                assert len(stream) == budget['example_exposures'] == 512
                assert len(log) == budget['optimizer_steps'] == 128
                assert len({r['task_id'] for r in stream}) == 256
                assert len({r['panel_id'] for r in stream}) == 64
                assert reload['maximum_error'] == 0
                streams.add(sha(path / 'training_stream.jsonl'))
                eval_binding = read(root / 'evaluations' / path.name / 'binding.json')
                assert eval_binding['training_receipt_hash'] == sha(path / 'DONE')
                assert eval_binding['adapter_hash'] == receipt['payload_hash']
                assert eval_binding['base_hash'] == receipt['binding']['base_hash']
                training[path.name] = {'budget': budget, 'reload': reload, 'binding': receipt['binding'],
                    'stream_sha256': sha(path / 'training_stream.jsonl'),
                    'all_gradients_clipped': all(r['gradient_norm'] > 1 for r in log),
                    'epochs': [{k: float(np.mean([r[k] for r in log[start:start+64]]))
                                for k in log[0] if k not in ('step', 'seconds')} for start in (0, 64)]}
            assert len(streams) == 1, 'Q3 conditions did not see identical training streams'
    table(out / 'ordinary_metrics.csv', metrics)
    table(out / 'panel_metrics.csv', panel_table)
    table(out / 'atomic_retention.csv', atomic)
    table(out / 'diagnostics.csv', diagnostics)
    table(out / 'hitk_curves.csv', curves)
    save(out / 'dataset_support.json', support)
    save(out / 'training_audit.json', training)
    save(out / 'replay_checks.json', verification)
    save(out / 'top_programs.json', examples)
    primary = {}
    for q, c, t in [('Q1', 'atomic_control', 'composition'), ('Q3', 'ce', 'ce_cf'),
                    ('Q3', 'ce', 'ce_entropy'), ('Q3', 'ce', 'ce_cf_entropy'), ('Q3', 'ce_entropy', 'ce_cf_entropy')]:
        paths = [p for p in (work / q / 'results/evaluations').iterdir() if read(p / 'binding.json')['config']['arm'] in (c, t)]
        name = f'{q}_{t}_minus_{c}'
        destination = out / 'comparisons' / (name + '.json')
        compare(sorted(paths), c, t, destination)
        result = read(destination)
        # Temporary extraction paths are replaced by portable archive member paths.
        for key in ('sources', 'exposure_ledgers'):
            result[key] = {f'{q}/' + str(Path(k).relative_to(work / q)): v for k, v in result[key].items()}
        save(destination, result)
        primary[name] = result
    exploratory = {}
    for q, weights in [
        ('Q1', {'composition': 1, 'atomic_control': -1}), ('Q1', {'composition': 1, 'baseline': -1}),
        ('Q3', {'ce': 1, 'initial': -1}), ('Q3', {'ce_cf': 1, 'ce': -1}),
        ('Q3', {'ce_entropy': 1, 'ce': -1}), ('Q3', {'ce_cf_entropy': 1, 'ce': -1}),
        ('Q3', {'ce_cf_entropy': 1, 'ce_cf': -1, 'ce_entropy': -1, 'ce': 1})]:
        name = q + '_' + '_'.join(f'{a}:{w}' for a, w in weights.items())
        exploratory[name] = extra_contrast(units, q, weights)
    save(out / 'exploratory_contrasts.json', exploratory)
    means = {}
    for q, arm in sorted({(r['queue'], r['arm']) for r in diagnostics}):
        rows = [r for r in diagnostics if (r['queue'], r['arm']) == (q, arm) and r['family'] in ('B', 'D')]
        atom = [r for r in atomic if (r['queue'], r['arm'], r['operation']) == (q, arm, 'ALL')]
        panels = [r for r in panel_table if (r['queue'], r['arm'], r['policy']) == (q, arm, 'local') and r['family'] in ('B', 'D')]
        means[q + '/' + arm] = {k: float(np.mean([r[k] for r in rows])) for k in rows[0] if k not in ('queue', 'mask', 'arm', 'seed', 'family')}
        means[q + '/' + arm].update(atomic_plan=float(np.mean([r['plan'] for r in atom])),
            atomic_apply=float(np.mean([r['apply'] for r in atom])),
            crossed_joint=float(np.mean([r['all_cells_strict'] for r in panels if r['kind'] == 'crossed'])),
            crossed_cell=float(np.mean([r['cell_accuracy'] for r in panels if r['kind'] == 'crossed'])),
            four_target=float(np.mean([r['pair_accuracy'] for r in panels if r['kind'] == 'four_target'])))
    save(out / 'key_results.json', means)
    return primary, exploratory, means, curves, atomic


def plots(out, primary, exploratory, means, curves, atomic):
    os.environ.setdefault('MPLCONFIGDIR', '/tmp/iclr_q1q3_matplotlib')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9, 'axes.spines.top': False,
                         'axes.spines.right': False, 'pdf.fonttype': 42})
    fig, axes = plt.subplots(2, 2, figsize=(11, 7.5), constrained_layout=True)
    for ax, q, c, treatments in [(axes[0, 0], 'Q1', 'atomic_control', ['composition']),
                                (axes[0, 1], 'Q3', 'ce', ['ce_cf', 'ce_entropy', 'ce_cf_entropy'])]:
        labels, values, low, high = [], [], [], []
        for t in treatments:
            for endpoint, label in [('crossed_joint_accuracy_strict', 'Crossed joint'), ('four_target_pair_accuracy', 'Four-TARGET')]:
                r = primary[f'{q}_{t}_minus_{c}']['endpoints'][endpoint]
                labels.append(f'{t}: {label}'); values.append(100 * r['estimate'])
                low.append(100 * r['ci95'][0]); high.append(100 * r['ci95'][1])
        if q == 'Q1':
            for endpoint, label in [('ordinary_hit1', 'Ordinary Hit@1'), ('ordinary_hit8', 'Ordinary Hit@8')]:
                r = primary['Q1_composition_minus_atomic_control']['endpoints'][endpoint]
                labels.append(label); values.append(100*r['estimate']); low.append(100*r['ci95'][0]); high.append(100*r['ci95'][1])
        x = np.array(values)
        ax.errorbar(x, np.arange(len(x)), xerr=[x-np.array(low), np.array(high)-x], fmt='o', color='#0072B2', capsize=3)
        ax.axvline(0, color='0.5', lw=.8); ax.set_yticks(np.arange(len(x)), labels); ax.invert_yaxis()
        ax.set_xlabel(f'Difference vs {c} (percentage points)')
        ax.set_title(f'{q}: paired dev contrasts, equal B/D', loc='left', fontweight='bold')
        ax.grid(axis='x', alpha=.2)
    ax = axes[1, 0]
    for arm, color, linestyle in [('baseline', '#999999', ':'), ('atomic_control', '#0072B2', '--'), ('composition', '#D55E00', '-')]:
        values = [np.mean([r['hit'] for r in curves if (r['queue'], r['arm'], r['k']) == ('Q1', arm, k) and r['family'] in ('B', 'D')]) for k in range(1, 126)]
        ax.plot(range(1, 126), 100*np.array(values), label=arm, color=color, linestyle=linestyle)
    ax.plot([1, 125], [100/125, 100], color='0.3', lw=.8, linestyle='-.', label='Uniform random ranking')
    ax.axvline(32, color='0.7', lw=.8); ax.set(xlabel='Ranking budget K', ylabel='Hit@K (%)', xlim=(1,125), ylim=(0,100))
    ax.set_title('Q1: full 125-program ranking, ordinary B/D', loc='left', fontweight='bold'); ax.legend(fontsize=8)
    ax = axes[1, 1]
    arms = ['initial', 'ce', 'ce_entropy', 'ce_cf', 'ce_cf_entropy']
    for metric, label, color, marker in [('atomic_plan', 'Atomic PLAN', '#0072B2', 'o'), ('atomic_apply', 'Atomic APPLY', '#D55E00', 's')]:
        ax.plot(range(5), [100*means['Q3/'+a][metric] for a in arms], marker=marker, label=label, color=color)
    ax.set_xticks(range(5), ['Initial', 'CE', 'CE+H', 'CE+CF', 'CE+CF+H']); ax.set_ylim(0, 105)
    ax.set_ylabel('Accuracy (%)'); ax.set_title('Q3: atomic retention, 1,000 tasks per arm', loc='left', fontweight='bold'); ax.legend()
    fig.suptitle('Qwen3-0.6B, BF16 | Q1: 3 continuation seeds, original mask | Q3: seed 0, mask1', fontsize=11)
    for ext in ('png', 'pdf'):
        fig.savefig(out / ('overview.'+ext), dpi=300)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archives', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--out', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    self_check()
    with tempfile.TemporaryDirectory(prefix='iclr_v4_analysis_') as temporary:
        work = Path(temporary)
        audit = {q: unpack(args.archives/name, digest, work/q) for q, (name, digest) in ARCHIVES.items()}
        # Both exports contain the same snapshot; do not import a mutable checkout.
        for path in (work/'Q1/code').rglob('*'):
            if path.is_file():
                assert path.read_bytes() == (work/'Q3/code'/path.relative_to(work/'Q1/code')).read_bytes()
        outputs = analyze(work, args.out)
        plots(args.out, *outputs)
        audit['scope'] = 'CPU replay of saved scores; model inference and training not repeated; weight hashes not independently recomputed.'
        audit['remote_head_verified_read_only'] = COMMIT
        audit['archive_code_compared_to_git_head'] = 'All archived code files per archive matched this commit during the original 2026-09-22 analysis session; this command does not contact GitHub.'
        audit['self_check'] = 'passed'
        audit['analysis_script_sha256'] = sha(Path(__file__))
        audit['python'] = sys.version
        audit['numpy'] = np.__version__
        save(args.out / 'archive_audit.json', audit)
    print('Finished:', args.out.resolve(), flush=True)


if __name__ == '__main__':
    main()
