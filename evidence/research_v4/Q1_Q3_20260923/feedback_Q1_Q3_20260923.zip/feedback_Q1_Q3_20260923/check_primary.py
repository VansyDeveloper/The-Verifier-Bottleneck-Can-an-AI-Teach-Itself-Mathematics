#!/usr/bin/env python3
"""Verify this compact feedback bundle and replay all five paired v4 comparisons."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent


def main():
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    for entry in manifest['files']:
        path = (ROOT / entry['path']).resolve()
        assert path.is_relative_to(ROOT), entry['path']
        data = path.read_bytes()
        assert len(data) == entry['bytes'], entry['path']
        assert hashlib.sha256(data).hexdigest() == entry['sha256'], entry['path']
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(ROOT / 'protocol'))
    from iclr.research_analysis import ENDPOINTS

    runs = defaultdict(dict)
    with (ROOT / 'primary_observations.jsonl').open() as stream:
        for line in stream:
            row = json.loads(line)
            key = row['endpoint'], row['family'], row['unit']
            run = runs[row['queue'], row['seed'], row['arm']]
            assert key not in run, 'Duplicate observation'
            assert np.isfinite(row['value'])
            run[key] = row['identity_sha256'], row['value']
    sources = json.loads((ROOT / 'primary_observations_sources.json').read_text())
    assert len(runs) == 12 and sum(map(len, runs.values())) == sources['rows'] == 16752
    checked = 0
    for path in sorted((ROOT / 'analysis/comparisons').glob('*.json')):
        report = json.loads(path.read_text())
        q = path.name.split('_')[0]
        c, t = report['control'], report['treatment']
        selected = {(s, a): values for (queue, s, a), values in runs.items() if queue == q and a in (c, t)}
        seeds = sorted({s for s, a in selected})
        assert set(selected) == {(s, a) for s in seeds for a in (c, t)}
        keys = set(next(iter(selected.values())))
        assert all(set(v) == keys for v in selected.values()), 'Unpaired units'
        rng = np.random.default_rng(20260922)
        for endpoint in ENDPOINTS:
            by_family, per_seed = defaultdict(list), defaultdict(list)
            for key in sorted(k for k in keys if k[0] == endpoint):
                cells = [selected[s, a][key] for s in seeds for a in (c, t)]
                assert len({r[0] for r in cells}) == 1, 'Different task/panel identities'
                delta = [selected[s, t][key][1] - selected[s, c][key][1] for s in seeds]
                by_family[key[1]].append(float(np.mean(delta)))
                for seed, value in zip(seeds, delta):
                    per_seed[seed, key[1]].append(value)
            expected = report['endpoints'][endpoint]
            if not by_family:
                assert not expected['available_in_all_masks'] and expected['estimate'] is None
                continue
            assert set(by_family) == {'B', 'D'} and expected['available_in_all_masks']
            assert len(expected['masks']) == 1 and expected['masks'][0]['seeds'] == seeds
            draws = []
            for family in ('B', 'D'):
                v = np.asarray(by_family[family])
                draws.append(v[rng.integers(len(v), size=(2000, len(v)))].mean(1))
                recorded = expected['masks'][0]['families'][family]
                assert len(v) == recorded['units']
                np.testing.assert_allclose(v.mean(), recorded['estimate'], rtol=0, atol=1e-12)
            mean = float(np.mean([np.mean(v) for v in by_family.values()]))
            ci = np.quantile(np.mean(draws, axis=0), [.025, .975])
            np.testing.assert_allclose([mean, *ci], [expected['estimate'], *expected['ci95']], rtol=0, atol=1e-12)
            for seed in seeds:
                value = np.mean([np.mean(per_seed[seed, f]) for f in ('B', 'D')])
                np.testing.assert_allclose(value, expected['masks'][0]['per_seed'][str(seed)], rtol=0, atol=1e-12)
            checked += 1
        print('PASS', path.name)

    # Check the mathematical illustration in the feedback note, not a model claim.
    before = np.array([3., 1., 1., 3.])
    after = before - 2
    signs = np.array([1., -1., -1., 1.])
    assert not (before * signs > 0).all() and (after * signs > 0).all()
    assert before @ signs == after @ signs == 4
    assert checked == 35
    print(f'PASS: {len(manifest["files"])} file hashes; {checked} endpoint comparisons; paired identities and per-seed values.')
    print('Scope: stored panel/START-cluster values. Raw logits and model inference are not replayed.')


if __name__ == '__main__':
    main()
